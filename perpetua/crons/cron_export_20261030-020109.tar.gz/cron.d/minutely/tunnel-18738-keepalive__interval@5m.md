---
id: tunnel-18738-keepalive
title: Gemini Live 桥接隧道保活
enabled: true
mode: task
schedule:
  kind: interval
  timezone: Asia/Shanghai
  at: 2026-10-12T11:43:00
  every: 5m
delivery:
  - chat_id: bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46
metadata:
  tags: [cron:automatic-interval-anchor]
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","event_kind":"message","require_mention":false,"device_id":"540d94c12687e47c"}'
  presentation_locale: en-US
---
运行保活脚本，确保 Gemini Live 桥接隧道（VM 127.0.0.1:18738 → VPS 18738）存活。

执行：`bash /home/hatch/data/perpetua/vps_console/tunnel_18738_keepalive.sh`

静默运行，不打扰用户。
