---
id: perpetua-dashboard-refresh
enabled: true
owner: space:perpetua-dashboard
execution:
  kind: space_action
  slug: perpetua-dashboard
  action: refreshdashboardsnapshot
  args: {}
mode: task
schedule:
  kind: interval
  timezone: Asia/Shanghai
  at: 2026-10-06T12:53:45
  every: 30m
metadata:
  tags: [cron:automatic-interval-anchor]
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","event_kind":"message","require_mention":false,"device_id":"540d94c12687e47c"}'
  presentation_locale: en-US
---
Invoke the web artifact's published scheduled action and retain its run history.
