---
id: local-chrome-keepalive
title: 本机备用 Chrome 保活
enabled: true
mode: task
schedule:
  kind: interval
  timezone: Asia/Shanghai
  at: 2026-10-15T12:03:33
  every: 5m
delivery:
  - chat_id: bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46
metadata:
  tags: [cron:automatic-interval-anchor]
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","event_kind":"message","require_mention":false,"device_id":"540d94c12687e47c"}'
  presentation_locale: en-US
---
本机备用 Chrome 保活（2026-10-15 立项，geminigen 故障转移用）：

执行：`bash /home/hatch/bin/local-chrome-keepalive.sh`

该脚本检查本机 Chrome（CDP 9335，VPS profile 复制版）是否存活，死了自动拉起。
这是 `geminigen_api.py --backend local/auto` 的故障转移浏览器，VPS 浏览器挂了时本机接管生成。

静默运行：正常时不打扰；拉起成功/失败在 handoff 中简述。
