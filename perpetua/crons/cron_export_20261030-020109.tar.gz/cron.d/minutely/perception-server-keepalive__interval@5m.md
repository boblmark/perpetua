---
id: perception-server-keepalive
title: perception server 保活（18736）
enabled: true
mode: task
schedule:
  kind: interval
  timezone: Asia/Shanghai
  at: 2026-10-12T10:51:28
  every: 5m
delivery:
  - chat_id: bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46
metadata:
  tags: [cron:automatic-interval-anchor]
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","event_kind":"message","require_mention":false,"device_id":"540d94c12687e47c"}'
  presentation_locale: en-US
---
运行保活脚本，检查 perception server（ws://127.0.0.1:18736）是否存活，挂了则拉起。

执行：`bash /home/hatch/data/perpetua/vps_console/perception_keepalive.sh`

脚本逻辑：用 ss 检查 18736 监听状态，连续两次（间隔 10s）失败才重启，防误杀。重启时精确 pkill `perception_server.py`，用 venv Python 拉起。

静默运行，不打扰用户。只在日志 `/home/hatch/data/perpetua/vps_console/perception_keepalive.log` 留记录。
