---
id: tunnel-nano-keepalive
title: nano 隧道保活（18736/18737/18739）
enabled: true
mode: task
schedule:
  kind: interval
  timezone: Asia/Shanghai
  at: 2026-10-12T10:51:37
  every: 5m
delivery:
  - chat_id: bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46
metadata:
  tags: [cron:automatic-interval-anchor]
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","event_kind":"message","require_mention":false,"device_id":"540d94c12687e47c"}'
  presentation_locale: en-US
---
运行保活脚本，确保 nano 反向隧道脚本（tunnel_nano.sh）本身在运行。

执行：`bash /home/hatch/data/perpetua/vps_console/tunnel_nano_keepalive.sh`

脚本逻辑：用 pgrep 检查 tunnel_nano.sh 进程，不在才拉起。拉起前精确清理残留的 ssh 转发进程（只杀同时含 18736/18737/18739 三个端口的，避免误杀其他隧道如 8080/MCP）。

隧道脚本内已有 while true 重连，这里只保脚本进程本身。静默运行，不打扰用户。日志：`/home/hatch/data/perpetua/vps_console/tunnel_nano_keepalive.log`。
