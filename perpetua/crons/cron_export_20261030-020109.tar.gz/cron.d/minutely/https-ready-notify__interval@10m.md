---
id: https-ready-notify
title: viralloopapp.com HTTPS 就绪通知
enabled: true
mode: task
schedule:
  kind: interval
  timezone: Asia/Shanghai
  at: 2026-10-07T17:31:31
  every: 10m
delivery:
  - chat_id: bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46
metadata:
  tags: [cron:automatic-interval-anchor]
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","event_kind":"message","require_mention":false,"device_id":"540d94c12687e47c"}'
  presentation_locale: en-US
---
检查 viralloopapp.com 的 HTTPS 是否已就绪。运行：
`~/workspace/goals/karenvsai/hidden_files/https-ready-watch.sh`
- 如果输出包含 "READY"，说明 https://oa.viralloopapp.com、https://viralloopapp.com、https://www.viralloopapp.com 三个站点都已可通过 HTTPS 访问。向用户报告就绪，附上三个 URL 请用户验证访问是否正常。
- 如果无输出，说明还没就绪，静默结束（不要打扰用户）。
注意：脚本自带状态文件，只会输出一次 READY。
