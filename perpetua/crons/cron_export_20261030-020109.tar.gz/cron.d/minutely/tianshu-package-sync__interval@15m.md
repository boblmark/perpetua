---
id: tianshu-package-sync
title: 天枢安装包同步检查
enabled: true
mode: task
schedule:
  kind: interval
  timezone: Asia/Shanghai
  at: 2026-10-14T14:07:03
  every: 15m
delivery:
  - chat_id: bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46
metadata:
  tags: [cron:automatic-interval-anchor]
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","event_kind":"message","require_mention":false,"device_id":"540d94c12687e47c"}'
  presentation_locale: en-US
---
天枢安装包同步检查（每 15 分钟，与 Perpetua 完全独立）：

1. 计算 /home/hatch/platform 当前源码校验和：
```bash
python3 -c "
import hashlib, json, os
src='/home/hatch/platform'
exts={'.py','.html','.js','.css','.sh','.md','.txt','.yaml','.yml','.service','.json'}
files=set()
for root, dirs, filenames in os.walk(src):
    dirs[:] = [d for d in dirs if d not in ('.git','__pycache__','node_modules')]
    for f in filenames:
        if os.path.splitext(f)[1].lower() in exts:
            files.add(os.path.join(root, f))
h=hashlib.sha256()
for f in sorted(files):
    try: h.update(open(f,'rb').read())
    except: pass
print(h.hexdigest())
"
```

2. 对比 `/home/hatch/workspace/your_files/.tianshu_package_manifest.json` 中的 sha256。

3. 如果不一致（有增删改）→ 运行 `bash /home/hatch/platform/build_tianshu_package.sh` 重建天枢安装包。

4. 如果一致 → 静默，不打扰用户。

5. 重建后在 handoff 中记录：重建了哪两个包、新的校验和前 16 位。

注意：只检测天枢源码（/home/hatch/platform），与 Perpetua 的包完全隔离。
