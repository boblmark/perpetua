---
id: tunnel-18901-keepalive
title: 天枢控制台 18901 隧道保活
enabled: true
mode: task
schedule:
  kind: interval
  timezone: Asia/Shanghai
  at: 2026-10-14T16:59:04
  every: 5m
delivery:
  - chat_id: bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46
metadata:
  tags: [cron:automatic-interval-anchor]
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","event_kind":"message","require_mention":false,"device_id":"540d94c12687e47c"}'
  presentation_locale: en-US
---
检查天枢控制台反向隧道（18901 → VPS）是否存活。判活锚定真实 ssh 转发进程，不查 wrapper 脚本名（2026-10-15 修：旧 `pgrep -f "tunnel_18901\.sh"` 会被执行命令自身的字面量自匹配，导致隧道已死却判存活的 false-pass）。

执行命令：
```bash
# 括号技巧：[-]R 只匹配真实 ssh 命令行里的 "-R"，不匹配本命令自身的字面量
if ! pgrep -f -- "[-]R 0[.]0[.]0[.]0:18901:" > /dev/null; then
  setsid nohup bash /home/hatch/data/perpetua/vps_console/tunnel_18901.sh > /dev/null 2>&1 < /dev/null &
  echo "tunnel_18901 relaunched at $(date)"
fi
# 验证 VPS 端端口在监听
timeout 20 ssh -i /home/hatch/.ssh/id_ed25519 -o StrictHostKeyChecking=no -o ProxyCommand="nc -X connect -x 198.19.0.1:3128 %h %p" -o ConnectTimeout=15 root@192.166.82.123 "ss -tln 2>/dev/null | grep ':18901'" || echo "WARNING: VPS 18901 not listening"
```

静默运行：隧道正常时不打扰用户；只有拉起隧道或 VPS 端端口缺失时才在当日日志 ~/memory/YYYY-MM-DD.md 记一笔。不要杀其他隧道进程。
