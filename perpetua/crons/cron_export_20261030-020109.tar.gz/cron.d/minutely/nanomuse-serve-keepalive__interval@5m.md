---
id: nanomuse-serve-keepalive
title: nanoMuse 主控制台保活（18739）
enabled: true
mode: task
schedule:
  kind: interval
  timezone: Asia/Shanghai
  at: 2026-10-12T10:51:22
  every: 5m
delivery:
  - chat_id: bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46
metadata:
  tags: [cron:automatic-interval-anchor]
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","event_kind":"message","require_mention":false,"device_id":"540d94c12687e47c"}'
  presentation_locale: en-US
---
运行保活脚本，检查 nanoMuse 主控制台（http://127.0.0.1:18739）是否存活，挂了则拉起。

执行：`bash /home/hatch/data/perpetua/vps_console/nanomuse_serve_keepalive.sh`

脚本逻辑：连续两次（间隔 10s）curl 探测失败才重启，防单次超时误杀。重启时精确 pkill `nanomuse serve --port 18739`，用 venv Python 拉起，NO_PROXY 已处理括号 IPv6 问题。

静默运行，不打扰用户。只在日志 `/home/hatch/data/perpetua/vps_console/nanomuse_serve_keepalive.log` 留记录。
