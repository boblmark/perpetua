---
id: nanomuse-mcp-tunnel-keepalive
title: nanoMuse MCP 隧道保活（8737）
enabled: true
mode: task
schedule:
  kind: interval
  timezone: Asia/Shanghai
  at: 2026-10-12T14:37:55
  every: 5m
metadata:
  tags: [cron:automatic-interval-anchor]
  originating_chat_context_json: '{"origin_provider":"main","chat_kind":"direct","event_kind":"message","require_mention":false}'
  presentation_locale: zh-CN
---
运行保活脚本，确保 nanoMuse MCP 的两部分都在运行：① MCP server 本体（127.0.0.1:8735，curl /health 检查，不健康则重启）；② 公网隧道脚本（~/workspace/nanomuse-mcp/tunnel.sh，pgrep 检查，不在才拉起；拉起前精确清理残留的 8737 ssh 转发进程，避免误杀其他隧道）。

隧道脚本内已有 while true 重连，这里只保脚本进程 + server 本体。静默运行，不打扰用户。日志：/home/hatch/workspace/nanomuse-mcp/keepalive.log。

执行：`bash /home/hatch/workspace/nanomuse-mcp/keepalive.sh`
