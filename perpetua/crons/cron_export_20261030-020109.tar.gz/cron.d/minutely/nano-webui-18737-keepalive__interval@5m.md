---
id: nano-webui-18737-keepalive
title: nano 语音 Web UI 保活（18737）
enabled: true
mode: task
schedule:
  kind: interval
  timezone: Asia/Shanghai
  at: 2026-10-14T06:29:54
  every: 5m
delivery:
  - chat_id: bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46
metadata:
  tags: [cron:automatic-interval-anchor]
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","event_kind":"message","require_mention":false}'
  presentation_locale: en-US
---
运行保活脚本，确保 nano 实时语音 Web UI（127.0.0.1:18737，perception/web 静态服务）存活，挂了则拉起。

执行：`bash /home/hatch/data/perpetua/vps_console/nano_webui_18737_keepalive.sh`

背景：18737 挂掉会导致 https://nano.viralloopapp.com 返回 502。2026-10-14 曾静默挂掉多日无人发现，故补独立保活。

脚本逻辑：连续两次（间隔 10s）curl 探测失败才重启，防单次超时误杀。重启时精确 pkill `http.server 18737`，用 setsid+nohup 拉起。

静默运行，不打扰用户。只在日志 `/home/hatch/data/perpetua/vps_console/nano_webui_18737_keepalive.log` 留记录。
