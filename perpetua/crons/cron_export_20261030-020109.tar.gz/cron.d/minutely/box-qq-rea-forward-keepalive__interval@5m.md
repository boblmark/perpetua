---
id: box-qq-rea-forward-keepalive
title: QQ box REA 主机侧接应保活（8746）
enabled: true
mode: task
schedule:
  kind: interval
  timezone: Asia/Shanghai
  at: 2026-10-28T14:39:08
  every: 5m
delivery:
  - chat_id: bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46
metadata:
  tags: [cron:automatic-interval-anchor]
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","event_kind":"message","require_mention":false,"device_id":"540d94c12687e47c"}'
  presentation_locale: en-US
---
QQ box REA 主机侧接应保活（每 5 分钟）：运行 `bash /home/hatch/data/perpetua/box_qq_rea_forward_keepalive.sh`，确保本机 127.0.0.1:8746 → VPS 127.0.0.1:8745 → QQ 盒子 box-qq-01 盒内 127.0.0.1:18790 转发存活。脚本自带判活（ssh 进程 + 本机 8746 端口监听）；健康时静默，只有重启了转发或启动失败时才在 handoff 里记一笔。注意：QQ 盒子内目前还没有 REA 网关，/healthz 检查暂不适用，不要以 /healthz 不通判转发死亡。不要改动 VPS 侧 box-qq-rea-forward.service 或老盒子的 box-rea-forward.service。
