---
id: box-qq-muse-forward-keepalive
title: QQ box muse 主机侧接应保活（8748）
enabled: true
mode: task
schedule:
  kind: interval
  timezone: Asia/Shanghai
  at: 2026-10-28T17:03:50
  every: 5m
delivery:
  - chat_id: bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46
metadata:
  tags: [cron:automatic-interval-anchor]
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","event_kind":"message","require_mention":false}'
  presentation_locale: en-US
---
QQ box muse 隧道保活（每 5 分钟）：运行本机接应脚本，确保本地 127.0.0.1:8748 → VPS 127.0.0.1:8747 → QQ 盒 127.0.0.1:8101 的 muse API 隧道存活，挂了则拉起。

执行：`bash /home/hatch/data/perpetua/box_qq_muse_forward_keepalive.sh`

背景：2026-10-28 为绕开 InstaBox 公开端口约 20 秒截断（80 秒 muse_video 调用必断）而建的 SSH 隧道；VPS 侧转发服务 box-qq-muse-forward.service（8747→盒内 8101）+ 本机接应（8748→VPS 8747）。

静默运行，不打扰用户。只在日志 /home/hatch/data/perpetua/box_qq_muse_forward_keepalive.log 留记录。
