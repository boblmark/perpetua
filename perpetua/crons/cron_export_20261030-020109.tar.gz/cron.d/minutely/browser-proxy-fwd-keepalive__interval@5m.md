---
id: browser-proxy-fwd-keepalive
title: 浏览器代理转发器保活
enabled: true
mode: task
schedule:
  kind: interval
  timezone: Asia/Shanghai
  at: 2026-10-12T17:07:06
  every: 5m
delivery:
  - chat_id: bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46
metadata:
  tags: [cron:automatic-interval-anchor]
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","event_kind":"message","require_mention":false,"device_id":"540d94c12687e47c"}'
  presentation_locale: en-US
---
运行保活脚本，确保 Chromium 代理转发器（127.0.0.1:3129 → 198.19.0.1:3128）在运行：

```bash
bash /home/hatch/data/perpetua/browser_proxy_fwd_keepalive.sh
```

背景：nanoMuse 的 Chromium 直连 egress 代理会稳定报 ERR_TUNNEL_CONNECTION_FAILED（TCP 层不兼容），必须经本地转发器中转。browser_backends.py 已改为优先走转发器。转发器挂了会导致 browser 工具再次全挂。

静默运行，转发器正常时不打扰用户；只有重启了转发器才在 handoff 里记一笔。
