---
id: perpetua-windows-build-watch
title: Perpetua Windows 构建监控
enabled: true
mode: task
schedule:
  kind: interval
  timezone: Asia/Shanghai
  at: 2026-10-06T15:01:25
  every: 10m
delivery:
  - chat_id: bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46
metadata:
  tags: [cron:automatic-interval-anchor]
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","event_kind":"message","require_mention":false}'
  presentation_locale: zh-CN
---
检查 Perpetua Windows 构建状态：运行 `python3 /home/hatch/data/perpetua/build_watch.py`。如果构建成功，把 Release 下载链接告诉用户；如果失败，告诉用户去看 Actions 日志。只在状态变化时通知，不要重复打扰。
