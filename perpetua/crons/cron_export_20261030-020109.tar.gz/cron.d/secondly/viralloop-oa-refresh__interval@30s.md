---
id: viralloop-oa-refresh
enabled: true
owner: space:viralloop-oa
execution:
  kind: space_action
  slug: viralloop-oa
  action: refreshdashboard
  args: {}
mode: task
concurrency:
  max_running: 1
  overlap: skip
schedule:
  kind: interval
  timezone: Asia/Shanghai
  at: 2026-10-07T15:22:37
  every: 30s
metadata:
  tags: [cron:automatic-interval-anchor]
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","event_kind":"message","require_mention":false,"device_id":"540d94c12687e47c"}'
  presentation_locale: en-US
---
Invoke the web artifact's published scheduled action and retain its run history.
