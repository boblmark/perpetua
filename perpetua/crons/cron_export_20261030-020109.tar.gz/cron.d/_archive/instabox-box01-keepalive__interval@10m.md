---
id: instabox-box01-keepalive
title: InstaBox box-01 保活（每10分钟）
enabled: true
mode: task
schedule:
  kind: interval
  timezone: Asia/Shanghai
  at: 2026-10-28T01:31:31
  every: 10m
delivery:
  - chat_id: bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46
metadata:
  tags: [cron:automatic-interval-anchor]
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","event_kind":"message","require_mention":false,"device_id":"540d94c12687e47c"}'
  presentation_locale: en-US
---
InstaBox 机器 box-01 保活（用户 2026-10-28 要求）：每 10 分钟访问一次它的公开保活地址 https://8080-agqx4qysbgww7oa6tgzbhvjl4m.instabox.tech/ ，curl 超时 60 秒（机器若正从暂停恢复，请求会等它醒来）。返回 ok 即正常，静默结束，不打扰用户。失败时在 handoff 里如实报告失败现象（curl 退出码、超时还是非 ok 内容），不要擅自改机器设置、删东西或重建服务；主 agent 会判断是否需要重新拉起盒内 keepalive 服务。注意：这个地址是公开 URL（官方文档说明它不是秘密），里面不含任何凭据；不要把任何 token、密钥写进报告或文件。
