---
id: viralloop-page-retry
title: ViralLoop 主页创建重试（限流冷却后）
enabled: true
mode: task
schedule:
  kind: interval
  timezone: Asia/Shanghai
  at: 2026-10-09T00:04:50
  every: 4h
delivery:
  - chat_id: bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46
metadata:
  tags: [cron:automatic-interval-anchor]
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","event_kind":"message","require_mention":false,"device_id":"540d94c12687e47c"}'
  presentation_locale: en-US
---
ViralLoop Facebook 公司主页创建重试（用户已批准方案1：等冷却过后自动重试）。

背景：2026-10-08 19:57 尝试创建 "ViralLoop" Facebook Page 时被 Facebook 限流（"最近尝试创建公共主页次数过多"）。表单已填好（名称 ViralLoop、类别软件公司、简介），只差最后提交。用户选择等冷却过后由定时任务自动重试。

本轮执行步骤：
1. 用 browser.spawn_task 派一个浏览器任务，附带文件 `workspace/uploads/viralloop-promo-60s-final.mp4`（38MB 宣传片）：
   - 先检查账号下是否已有名为 "ViralLoop" 的 Page（看 facebook.com/pages 或个人主页的 Page 列表）。
   - 如果已有：直接在这个 Page 上发布视频帖子（文案见下），然后置顶。
   - 如果没有：去 https://www.facebook.com/pages/create 按以下信息创建：
     - 名称：ViralLoop
     - 类别：软件公司（Software Company）
     - 简介：第一家基于 Meta Muse 打造的一人公司。用 AI 智能体全自动生产爆款短视频。The first one-person company built on Meta Muse — AI agents producing viral short videos end-to-end.
   - 如果创建仍被限流：不要硬刷，报告限流状态即可，等下一轮。
   - 创建成功后：在新 Page 上发布视频帖子并置顶。
   - 视频帖子文案：
     🚀 ViralLoop —— 第一家基于 Meta Muse 打造的一人公司
     
     一个人 + 一个 AI 智能体 = 一整家公司。
     从趋势捕捉、选题、视频生成、质检到发布，全链路自动化。
     
     这是用 Muse 亲手搭建的"爆款永动机"。
     One person. One AI agent. A whole company.
     
     #Muse #MetaAI #AIAgent #OnePersonCompany #ViralLoop
   - 不要动现有的 "Mark Bobl - Karen vs AI" Page（ID 61594841955473）。

2. 根据浏览器任务结果：
   - 如果 Page 创建成功 + 视频已发布 + 已置顶：用 cron.update 把本任务（id=viralloop-page-retry）设为 enabled=false 停掉，然后向用户报告 Page 链接。
   - 如果仍在限流：静默结束，不打扰用户，等下一轮（4小时后）。
   - 如果遇到需要用户出面的情况（如身份验证）：向用户报告具体情况。

注意：只在最终成功或需要用户出面时才向用户汇报；限流重试中的轮次保持静默。
