---
id: sleep-morning-report
title: 睡眠质量晨报（每日08:00）
enabled: true
mode: task
schedule:
  kind: daily
  timezone: '@user.current'
  time: 08:00:00
timeout_secs: 1200
delivery:
  - chat_id: bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46
metadata:
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","event_kind":"message","require_mention":false,"device_id":"540d94c12687e47c"}'
  presentation_locale: en-US
---
睡眠质量晨报（每天 08:00，Asia/Shanghai）。用户 cgb2026 用 Sleep as Android 监测睡眠，数据通道：SleepCloud 网页端为主，Health Connect 为辅（平台同步 bug 已报备，可能仍无数据）。

执行步骤：
1. 用浏览器打开 https://sleepcloud.urbandroid.org（已登录 cgb479023@gmail.com，条款已同意），读 GRAPHS/STATS，找昨夜（昨日 18:00 至今日 08:00 之间开始）的睡眠记录：开始/结束时间、总时长、评分、打鼾占比或时长、噪声事件（页面可见范围）。
2. 同时运行 health-cli status --provider healthconnect 看 sleep record_count；若 >0，再查最近一夜的 sleep 记录详情作补充/交叉核对。
3. 读 /home/hatch/data/sleep_monitor/state.json，把晨报覆盖的记录标识并入 processed，避免夜间巡检重复报告。
4. 生成晨报（本轮报告即晨报内容，主 agent 会原样转达用户），格式简洁：
   - 第一行：🌙 昨夜睡眠晨报（日期）
   - 时长：X 小时 X 分（评价：≥7h 良好 / 5–7h 一般 / <5h 不足）
   - 评分：XX（≥80 好 / 60–79 一般 / <60 差）
   - 打鼾：占比 XX%（<10% 正常 / 10–30% 偏高 / >30% 异常），有噪声事件数则附上
   - 一句话建议（针对当晚最弱的一项）
5. 若两个通道都没有昨夜数据：晨报写明「昨夜没有数据落地」+ 可能原因一句（未开追踪 / SleepCloud 未上传 / HC 同步仍故障），不要编造数据。
6. 浏览器只读，不改任何设置；不要调用 health.backfill。
