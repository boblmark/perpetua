---
id: geminigen-oauth-retry
title: geminigen cgb2025 会话自动恢复重试
enabled: true
mode: task
schedule:
  kind: interval
  timezone: Asia/Shanghai
  at: 2026-10-15T17:47:57
  every: 6h
delivery:
  - chat_id: bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46
metadata:
  tags: [cron:automatic-interval-anchor]
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","event_kind":"message","require_mention":false,"device_id":"540d94c12687e47c"}'
  presentation_locale: en-US
---
geminigen cgb2025 会话自动恢复重试（2026-10-15 立项）：

背景：VPS 上 geminigen 的 cgb2025（6365 额度）会话过期，Google OAuth 切账号时弹 "Verify it's you" reCAPTCHA（无其他验证方式），两次尝试均被拦。Google 风控分会波动，温和重试。

执行：`python3 /home/hatch/data/perpetua/geminigen_oauth_retry.py`，看输出状态行：
- ALREADY_CGB2025：已恢复，无需动作，静默。
- SUCCESS：本轮登录成功！这是重要状态变化，必须在 handoff 中醒目报告（cgb2025 会话已恢复，6365 额度可用，主 agent 需把 9222 也切过去并通知用户）。
- CHALLENGED：仍被验证码拦，正常，静默等下轮，不要尝试解验证码。
- 其他状态：记录原文，静默。

铁律：绝不点击/求解任何 CAPTCHA；只走正常登录流程；不改动 9222（9222 的切换由主 agent 手动做）。
