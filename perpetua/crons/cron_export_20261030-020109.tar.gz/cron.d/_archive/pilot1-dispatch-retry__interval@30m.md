---
id: pilot1-dispatch-retry
title: Pilot1 71分镜派发重试
enabled: true
owner: goal:karenvsai
mode: task
schedule:
  kind: interval
  timezone: Asia/Shanghai
  at: 2026-10-10T14:25:28
  every: 30m
delivery:
  - chat_id: bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46
metadata:
  tags: [cron:automatic-interval-anchor]
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","event_kind":"message","require_mention":false,"device_id":"540d94c12687e47c"}'
  presentation_locale: en-US
---
抖音 Pilot1 71分镜派发重试（幂等）。

执行：
```bash
cd /home/hatch/data/douyin && python3 dispatch_pilot1.py 2>&1 | tail -3
python3 -c "
import json
m = json.load(open('/home/hatch/data/douyin/pilot1_clip_jobs.json'))
ok = sum(1 for v in m.values() if v.get('muse_job_id'))
print(f'已提交 {ok}/71')
"
```

说明：
- dispatch_pilot1.py 幂等：已有 muse_job_id 的跳过，失败即停。
- 主 Muse 后端（backend b）每日预算 1000，2026-10-10 已用完，2026-10-11 08:00 CST 重置。预算恢复前提交会失败，这是正常的。
- 如果已提交数达到 71/71，在 handoff 中明确报告"71/71 全部提交完成，本 cron 可删除"，不要静默。
- 未达到 71 时静默结束（0 新增是正常状态）。
- 不要修改 pilot1_visual_prompts.py 或其他文件。
