---
id: comment-reply-retry-rb202610250058
title: 评论批 rb_202610250058 配额恢复后重发（一次性）
enabled: true
owner: goal:karenvsai
mode: task
schedule:
  kind: runonce
  timezone: Asia/Shanghai
  at: 2026-10-25T15:49:00
delivery:
  - chat_id: bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46
metadata:
  tags: [cron:flexible-time]
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","event_kind":"message","require_mention":false,"device_id":"540d94c12687e47c"}'
  presentation_locale: en-US
---
一次性重发已批准的评论回复批 rb_202610250058（用户 2026-10-25 09:37 亲选「下午配额恢复后重发」；上午 09:36 曾因 YouTube API 403 配额耗尽失败，2 条草稿仍在待发池）。

步骤：
1. 先核查 /home/hatch/data/perpetua/awaiting_approval.json 中该 batch：若已是 posted 且 2 条确实已发出，向用户报告已处理、不再重复发；若状态不是 approved，先不要动，向用户报告实际状态。
2. 若状态为 approved，运行 python3 /home/hatch/data/youtube/comment_reply_post.py --batch rb_202610250058，记录输出的 posted 数量。
3. 若 posted=2，向用户报告 2 条都已发出（附 2 个 comment_id）。
4. 若 posted<2（例如仍报 403）：这是已知脚本缺陷——脚本即使失败也会把 batch 标为 posted。必须把该 batch 在 awaiting_approval.json 里改回 approved 并删除 posted_at 字段（先备份原文件），保住重发资格，然后如实向用户报告失败原因和当前状态，不要在本轮内反复重试，不要另建新批。
5. 只发这 2 条已批准的草稿，不发其他评论，不做其他改动。

完成后向用户报告结果（成功或失败原因），本次任务即结束，不再重复执行。
