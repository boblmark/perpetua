---
id: console-restart-once-20261020
title: 控制台进程切换到当前版本（一次性）
enabled: true
owner: goal:karenvsai
mode: task
schedule:
  kind: runonce
  timezone: Asia/Shanghai
  at: 2026-10-20T14:10:00
delivery:
  - chat_id: bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46
metadata:
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","provider":"main","event_kind":"message","require_mention":false,"device_id":"18a85f72-3b82-4216-978c-008c08fe5597"}'
  presentation_locale: en-US
---
一次性任务：把 Perpetua 控制台（本机 127.0.0.1:8080）从旧代码进程切换到当前版本并验证。

背景：当前 8080 上跑的是从旧代码目录启动的 console_server.py，公网返回旧版前端（7 个 tab）。磁盘当前版本在 /home/hatch/data/perpetua/vps_console/（index.html 有 13 个 data-tab）。console_server.py 每次请求现读自身目录的 index.html，所以只需把进程换成从当前目录启动即可。

步骤（严格遵守：禁止宽泛 pkill -f；先列 PID 核对再精确 kill，kill 与启动分开执行）：
1. `ss -tlnp | grep :8080` 找到监听 PID；`readlink /proc/<PID>/cwd` 和 `tr '\0' ' ' < /proc/<PID>/cmdline` 记录老进程的目录与命令（写进报告）。
2. 精确 `kill <PID>`（5 秒后仍在则 `kill -9 <PID>`），确认 8080 端口已释放（ss 无监听）。
3. 启动新进程（单独一条命令，不要与 kill 拼在同一行）：`cd /home/hatch/data/perpetua/vps_console && CONSOLE_PORT=8080 setsid nohup python3 console_server.py >> console.out.log 2>&1 < /dev/null &`
4. 等 3 秒，验证：`curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:8080/` 应为 200；`curl -s http://127.0.0.1:8080/ | grep -o 'data-tab="[^"]*"' | sort -u | wc -l` 应为 13（含 battle/plugins/cadence/quarantine/agent/commander）。
5. 若 systemd 有 perpetua-console unit 且状态异常，只记录不处理。不要动任何隧道和其他服务。

报告：老 PID/cwd/cmdline、新 PID、curl 状态码、tab 数量与列表。完成后把结果追加到 ~/memory/2026-10-20.md 一行。
