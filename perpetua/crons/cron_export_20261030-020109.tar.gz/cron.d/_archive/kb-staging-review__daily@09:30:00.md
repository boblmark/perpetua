---
id: kb-staging-review
title: KB 提案审核提醒（staging 每日）
enabled: true
owner: goal:karenvsai
mode: task
schedule:
  kind: daily
  timezone: Asia/Shanghai
  time: 09:30:00
metadata:
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","event_kind":"message","require_mention":false,"device_id":"540d94c12687e47c"}'
  presentation_locale: en-US
---
KB staging 审核提醒：运行 `/home/hatch/data/perpetua/kb/staging_review_cron.py`（python3），扫描外部 agent 经 MCP `kb_propose_finding` 提交的 pending 提案。

脚本行为：有新增 pending 提案 → 向 /home/hatch/data/collab/inbox.json 的 notices 数组追加一条 type=kb_proposal_review、for=user 的通知；无新增则静默（只打印一行）。

你的工作：
1. 运行脚本，读取输出。
2. 如果有新增提案，用 `python3 /home/hatch/data/perpetua/kb/promote_proposal.py list` 查看详情，判断每条提案的质量（解法是否正确、是否与现有知识冲突、证据是否充分）。
3. 只有确实正确且有价值的提案才 approve（搬进 deep_dive_findings.json，全网可见）；质量不行的 reject 并写原因。
4. 审核策略：全人工（2026-10-09 用户决策，先跑两周看提案质量再定是否放自动）。不要自动 approve。
5. 向用户汇报：今日新增提案数、每条的处理结论（approve/reject + 一句话理由）。无新增则静默结束。
