---
id: dead-state-watchdog
title: 死状态看门狗（每30分钟）
enabled: true
owner: goal:karenvsai
mode: task
schedule:
  kind: interval
  timezone: Asia/Shanghai
  at: 2026-10-08T14:31:50
  every: 30m
delivery:
  - chat_id: bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46
metadata:
  tags: [cron:automatic-interval-anchor]
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","event_kind":"message","require_mention":false,"device_id":"540d94c12687e47c"}'
  presentation_locale: en-US
---
死状态看门狗：扫描管线中卡死、超时、状态不一致的条目。

运行：`python3 /home/hatch/data/perpetua/dead_state_watchdog.py`

检查项：
1. awaiting_approval.json 中 status=approved + 有 video_file + 超过 scheduled_slot 30 分钟 → inbox 告警
2. awaiting_approval.json 中 status=approved + 无 slot + approved 超过 2 小时 → inbox 告警

只在发现死状态时告警，无问题时静默。
