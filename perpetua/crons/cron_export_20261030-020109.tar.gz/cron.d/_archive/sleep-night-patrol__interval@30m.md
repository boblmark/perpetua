---
id: sleep-night-patrol
title: 睡眠夜间巡检（每30分钟）
enabled: true
mode: task
schedule:
  kind: interval
  timezone: Asia/Shanghai
  at: 2026-10-22T01:34:36
  every: 30m
timeout_secs: 1200
delivery:
  - chat_id: bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46
metadata:
  tags: [cron:automatic-interval-anchor]
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","event_kind":"message","require_mention":false,"device_id":"540d94c12687e47c"}'
  presentation_locale: en-US
---
睡眠夜间巡检（用户 cgb2026 的睡眠监测，Sleep as Android → SleepCloud 备选通道；Health Connect 平台同步 bug 已报备 Muse 团队，暂不可靠）。

执行步骤：
1. 时间窗检查：取当前 Asia/Shanghai 时间。不在 00:00–08:30 之间 → 只在 ~/memory 当日日志记一行「窗口外跳过」，静默结束。
2. 读状态文件 /home/hatch/data/sleep_monitor/state.json（不存在则按首次处理：{"processed": []}）。里面 processed 数组记录已处理过的 SleepCloud 记录标识（日期+开始时间）。
3. 查 Health Connect 同步状态：运行 health-cli status --provider healthconnect（命令不存在或报错则记录原样，不重试刷屏），记下 sleep 的 record_count。
4. 查 SleepCloud：用浏览器打开 https://sleepcloud.urbandroid.org（该浏览器已登录 cgb479023@gmail.com，服务条款已同意），进 GRAPHS 页看是否有睡眠记录。有记录时，读取最新 3 条的日期、开始/结束时间、时长、评分（页面可见原文），以及页面可见的打鼾/噪声信息。
5. 对比 state.json：出现未处理过的新记录 → 逐条分析并把标识追加进 state.json 的 processed（写回文件），分析结果记入 ~/memory 当日日志。分析口径：时长（≥7h 良好，5–7h 一般，<5h 差）、评分（≥80 好，60–79 一般，<60 差）、打鼾占比（<10% 正常，10–30% 偏高，>30% 异常）。
6. 报告规则（写进本轮报告，主 agent 会转达）：
   - 发现新记录且有异常（整段已结束但时长<3h 且结束早于 05:00；或评分<60；或打鼾占比>30%）→ 报告第一行写明异常要点和数据。
   - 发现新记录但无异常 → 报告里简述这条记录的关键数据（日期/时长/评分/打鼾）。
   - 没有新记录 → 报告只写「本轮无新数据」，保持简短。
7. 禁止事项：不要调用 device.invoke health.backfill（平台 bug 已知，6 次复现，避免无意义重试）；不要给用户提任何操作要求；不要改 SleepCloud/Sleep 的任何设置；浏览器只读。
