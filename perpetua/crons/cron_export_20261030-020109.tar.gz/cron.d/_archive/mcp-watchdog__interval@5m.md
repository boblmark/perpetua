---
id: mcp-watchdog
title: MCP server 看门狗
enabled: true
mode: task
schedule:
  kind: interval
  timezone: Asia/Shanghai
  at: 2026-10-05T11:16:26
  every: 5m
delivery:
  - chat_id: bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46
metadata:
  tags: [cron:automatic-interval-anchor]
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","event_kind":"message","require_mention":false,"device_id":"540d94c12687e47c"}'
  presentation_locale: en-US
---
MCP 协作基础设施看门狗：运行 `/home/hatch/data/mcp_server/venv/bin/python /home/hatch/data/mcp_server/watchdog.py`，它会检查 MCP server（127.0.0.1:8734）和 relay poller 是否存活，挂了就重启。运行后看脚本输出：一切正常则无需向用户报告；如果服务无法重启或反复崩溃，向用户简要说明情况。
