---
id: dispatch-lifeline-watch
title: 分发器生命线巡检
enabled: true
owner: goal:karenvsai
mode: task
schedule:
  kind: interval
  timezone: Asia/Shanghai
  at: 2026-10-15T11:07:49
  every: 10m
delivery:
  - chat_id: bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46
metadata:
  tags: [cron:automatic-interval-anchor]
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","event_kind":"message","require_mention":false,"device_id":"540d94c12687e47c"}'
  presentation_locale: en-US
---
分发器生命线巡检（2026-10-15 用户立：生命线，断了整个系统停摆）：

运行 `python3 /home/hatch/data/perpetua/dispatch_health.py`，检查视频生成分发链每一环：
1. dispatcher 8740 存活
2. mcp-b 队列 pending 深度 + 消费者新鲜度
3. geminigen 会话（401=掉线）+ 额度（空 POST 正文）
4. H3 tunnel、vids 配额、builtin 地区墙（已知状态）

脚本 exit=0（HEALTHY）→ 静默，只记 run log。
exit=1（DEGRADED）→ handoff 报告各环节状态。
exit=2（DOWN）或输出含 "alert" 非空 → 立刻在 handoff 全文报告，这是用户明确要求的生命线告警，不许静默。

注意：这是只读探针，不提交任何生成任务，不改队列。
