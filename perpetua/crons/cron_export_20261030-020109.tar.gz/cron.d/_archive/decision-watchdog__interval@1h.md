---
id: decision-watchdog
title: 决策登记处看门狗（每小时）
enabled: true
mode: task
schedule:
  kind: interval
  timezone: Asia/Shanghai
  at: 2026-10-10T09:20:27
  every: 1h
delivery:
  - chat_id: bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46
metadata:
  tags: [cron:automatic-interval-anchor]
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","provider":"main","event_kind":"message","require_mention":false,"device_id":"540d94c12687e47c"}'
  presentation_locale: en-US
---
决策登记处内容看门狗：运行 `bash /home/hatch/data/brain_council/decision_watchdog.sh`。脚本校验：① 登记处条目格式（D-ID）；② ID 无重复；③ 7 天内有 synthesis.md/conclusion.md 的议会目录必须有同日期登记条目；④ 取代指向的目标 ID 必须存在。告警写入 /home/hatch/data/brain_council/ALERTS.log 并 mirror 到当日 memory 日志。ALERTS.log 为空 = 全部通过，保持静默；有新增告警才在 handoff 中报告新增条目。
