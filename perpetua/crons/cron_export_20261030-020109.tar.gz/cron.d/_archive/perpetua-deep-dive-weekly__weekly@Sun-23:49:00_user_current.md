---
id: perpetua-deep-dive-weekly
title: Perpetua 深度复盘（每周自动诊断+进化）
enabled: true
owner: goal:karenvsai
mode: task
schedule:
  kind: weekly
  timezone: '@user.current'
  time: 23:49:00
  dow: [Sun]
delivery:
  - chat_id: bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46
metadata:
  tags: [cron:flexible-time]
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","provider":"main","event_kind":"message","require_mention":false,"device_id":"540d94c12687e47c"}'
  presentation_locale: en-US
---
Perpetua 每周深度复盘：不需要用户触发，自动做根因诊断并进化流程。

步骤：
1. 运行 `python3 /home/hatch/data/perpetua/daily_evolution.py` 确认本周数据已汇总。
2. 拉取近 7 天发布视频的完整数据（标题/描述/标签/发布时间/播放/点赞/评论），用 YouTube Data API（只读，凭据 /home/hatch/data/youtube/.oauth.json）。
3. 数据诊断：
   - 爆款（>2x 频道均值）vs 哑火（<50 播放）对比：标题结构、发布时间分布、标签完整度、语言/主题偏离
   - 检查发布时间是否集中（同一小时内多条=互食）
   - 检查标题主语（报应动词前是否有 Karen）、emoji 位置、元数据完整度
4. 向 Ask Studio 提问（用 browser.spawn_task，频道已登录）：
   "My channel @karenvsai published [N] Shorts this week: [X] viral, [Y] flopped. Diagnose root cause ranked by likelihood and give 3 concrete fixes for next week."
   把回答原文存到报告里。
5. 输出报告到 /home/hatch/data/perpetua/deep_dive_YYYY-MM-DD.md，包含：本周战绩、根因排序（数据+Ask Studio 双视角）、流程优化建议。
6. 自动进化（不需要用户批准的小改）：
   - criteria.json 发现新规律 → 版本+1（自动备份）
   - 标题校验规则有新发现 → 更新到 youtube_upload 门禁
7. 需要用户决定的大改（如降频、改定位）→ 写进报告并在聊天中通知用户，附具体建议。
8. 如果本周无发布或样本不足，静默结束。

注意：只读分析 + 小参数进化，不删除/修改任何已发布视频，不擅自改发布频率。
