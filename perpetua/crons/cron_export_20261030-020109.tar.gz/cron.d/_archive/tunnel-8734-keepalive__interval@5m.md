---
id: tunnel-8734-keepalive
title: 8734 隧道保活（MCP server 公网暴露）
enabled: true
mode: task
schedule:
  kind: interval
  timezone: Asia/Shanghai
  at: 2026-10-14T00:14:08
  every: 5m
delivery:
  - chat_id: bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46
metadata:
  tags: [cron:automatic-interval-anchor]
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","event_kind":"message","require_mention":false,"device_id":"540d94c12687e47c"}'
  presentation_locale: en-US
---
运行保活脚本，确保 8734 反向隧道（本机 MCP server 127.0.0.1:8734 → VPS 192.166.82.123:8734）存活。

执行：`bash /home/hatch/data/perpetua/vps_console/tunnel_8734_keepalive.sh`

用户 2026-10-14 00:08 CST 明确批准（Tier 3）。静默运行，不打扰用户；只有重启了隧道才在 handoff 里记一笔。
