---
id: box-rea-forward-keepalive
title: box REA 主机侧接应保活（8744）
enabled: true
mode: task
schedule:
  kind: interval
  timezone: Asia/Shanghai
  at: 2026-10-28T03:11:31
  every: 5m
delivery:
  - chat_id: bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46
metadata:
  tags: [cron:automatic-interval-anchor]
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","event_kind":"message","require_mention":false,"device_id":"540d94c12687e47c"}'
  presentation_locale: en-US
---
box REA 主机侧接应保活（每 5 分钟）：运行 `bash /home/hatch/data/perpetua/box_rea_forward_keepalive.sh`，确保本机 127.0.0.1:8744 → VPS 127.0.0.1:8743 → 盒 REA 网关（盒 127.0.0.1:18790）转发存活。脚本自带判活（ssh 进程 + /healthz 端点实测），健康时静默；只有重启了转发或启动失败时才在 handoff 里记一笔。不要改动 VPS 侧 box-rea-forward.service 或盒侧 rea-gateway.service。
