---
id: mcp-media-job-processor
title: MCP 媒体任务自动处理
enabled: true
mode: task
schedule:
  kind: interval
  timezone: Asia/Shanghai
  at: 2026-10-05T15:41:20
  every: 10m
timeout_secs: 600
delivery:
  - chat_id: bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46
metadata:
  tags: [cron:automatic-interval-anchor]
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","event_kind":"message","require_mention":false,"device_id":"540d94c12687e47c"}'
  presentation_locale: en-US
---
检查并处理 MCP 任务队列中的媒体生成任务。

步骤：
1. 列出 `/home/hatch/data/mcp_jobs/pending/` 下所有 `*.json` 文件（不含 `.result.json`）。
2. 对每个文件，读取内容。如果 `job_type` 是 `generate_image` 或 `generate_video`：
   - `generate_image`：用 media.generate_image，prompt 取自 payload.prompt（或 payload.raw），保存到 `/home/hatch/data/`（文件名含 job_id）。
   - `generate_video`：用 media.generate_video，prompt 取自 payload.prompt，保存到 `/home/hatch/data/`。
   - 生成成功后，把原 job 文件移到 `/home/hatch/data/mcp_jobs/done/`，并写入 `{job_id}.result.json`，内容含 `status: done`、`file`（生成的文件路径）、`job_id`。
   - 同时更新 `/home/hatch/data/collab/inbox.json`，在 `pending_pickup` 追加 `{"file": "<文件名>", "title": "<payload.title或job_id>", "created": "<ISO时间>", "status": "ready"}`。
3. 如果没有待处理的媒体任务，静默结束，无需报告。
4. 如果有处理失败的，记录错误到结果文件中，`status: failed`，继续处理下一个。

注意：只处理 `generate_image` 和 `generate_video`；其他 job_type（如 note、collab_poll）跳过。
生成的文件必须放在 `/home/hatch/data/` 下，外部 agent 经 MCP `read_file` 可取。
