---
id: wechat-daily-digest
title: 微信每日未读汇总
enabled: true
mode: task
schedule:
  kind: daily
  timezone: Asia/Shanghai
  time: 22:00:00
delivery:
  - chat_id: bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46
metadata:
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","event_kind":"message","require_mention":false,"device_id":"540d94c12687e47c"}'
  presentation_locale: en-US
---
微信每日未读消息汇总（每天 22:00）。

步骤：
1. 调用 device.invoke，device 为用户手机（540d94c12687e47c），command 为 notifications.get，获取当前所有活跃通知。
2. 筛选出微信的通知（app 为"微信"或 app_package 为 com.tencent.mm）。
3. 如果没有微信通知，本轮静默结束，无需打扰用户。
4. 如果有，按发送人分组整理，每条包含：发送人、时间、消息预览内容。
5. 用中文给用户发一条汇总消息，格式示例：
   "今日微信未读（X 条）：
    - [发送人] HH:MM：消息预览…
    - …"
6. 只汇总，不回复、不消除通知。
