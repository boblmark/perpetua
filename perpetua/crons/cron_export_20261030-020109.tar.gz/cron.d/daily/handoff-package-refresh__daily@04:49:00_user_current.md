---
id: handoff-package-refresh
title: 交接包每日刷新
enabled: true
mode: task
schedule:
  kind: daily
  timezone: '@user.current'
  time: 04:49:00
delivery:
  - chat_id: bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46
metadata:
  tags: [cron:flexible-time]
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","event_kind":"message","require_mention":false,"device_id":"540d94c12687e47c"}'
  presentation_locale: en-US
---
每日 04:00 重新生成 Dash 交接包，保持新 agent 可随时接手。

执行：`python3 /home/hatch/workspace/handoff/export_handoff.py`

交接包位置：`/home/hatch/workspace/handoff/latest/`（含 RECEIVER_GUIDE.md、记忆、决策、服务清单、定时任务、凭据位置）。

静默运行，不打扰用户。失败时在 ~/memory/YYYY-MM-DD.md 记录。
