---
id: revert-exec-temp-allow-20261022
title: 回滚控制台 /api/exec 临时放行（2026-10-22）
enabled: true
mode: task
schedule:
  kind: runonce
  timezone: Asia/Shanghai
  at: 2026-10-22T15:33:00
delivery:
  - chat_id: bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46
metadata:
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","event_kind":"message","require_mention":false,"device_id":"18a85f72-3b82-4216-978c-008c08fe5597"}'
  presentation_locale: en-US
---
一次性回滚任务：撤销 2026-10-22 13:31 给 VPS nginx 临时加的 /api/exec 单 IP 放行（用户 13:30 批准，临时措施）。

执行步骤（SSH 到 VPS 192.166.82.123，约定：ProxyCommand 经 198.19.0.1:3128、key /home/hatch/.ssh/id_ed25519、UserKnownHostsFile=/home/hatch/.ssh/known_hosts_vps、BatchMode）：
1. 确认备份存在：/root/nginx-backups/viralloopapp.bak-20261022-1331-exec-temp
2. cp 该备份覆盖 /etc/nginx/sites-enabled/viralloopapp
3. nginx -t 通过后 systemctl reload nginx（测试不过则不要 reload，报告失败原因）
4. 验证：curl -sk -o /dev/null -w "%{http_code}" -X POST https://viralloopapp.com/api/exec 应为 403；https://viralloopapp.com/ 应为 401（站点正常）
5. 把回滚结果报告给用户（一行即可：临时放行已撤销、/api/exec 恢复 403）。失败也要报告，不得静默。
