---
id: cheap-machine-deal-watch
title: 便宜机器活动监控（LET/LowEndBox）
enabled: true
mode: task
schedule:
  kind: interval
  timezone: Asia/Shanghai
  at: 2026-11-15T14:10:43
  every: 1h
delivery:
  - chat_id: bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46
metadata:
  tags: [cron:automatic-interval-anchor]
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","event_kind":"message","require_mention":false,"device_id":"7dfdded3-def2-43da-8e2e-257146640fc9"}'
  presentation_locale: en-US
---
便宜机器活动监控（用户 2026-11-15 立：盯新的免费/超低价机器活动，如 RackNerd × AdminBolt 免费 VPS 赠送、InstaBox 免费档这类机会，抢到就报）。

每轮只读检查，不登录、不注册、不发帖、不报名、不花钱：

1. 来源（每轮都查）：
   - LowEndTalk 首页最新帖 + Giveaways & Freebies 板块的新帖（找标题含 FREE/GIVEAWAY/免费赠送的新主题）。
   - LowEndBox 博客最新文章（lowendbox.com/blog/），找免费 VPS、免费套餐、赠送活动的报道。
   - 一次网页搜索，找过去 24 小时内新出现的免费 VPS / 免费云电脑 / 免费套餐赠送消息。
2. 去重：已见清单在 ~/workspace/deal-watch/seen.json（不存在就新建）。每轮把查到的候选 URL 记入清单；已在清单里的不再重复上报。
3. 上报门槛（四条全满足才报）：
   - 新出现的，不在已见清单里；
   - 免费或接近免费：0 元赠送/免费套餐/免费试用转长期，或 VPS 明显低于市价的超值价（年付 ≤15 美元的突出 deal）；
   - 仍开放可参与：必须读到帖子/文章的最新状态确认未结束，状态不明就如实写“未确认是否仍开放”，不许猜；
   - 不是常规付费广告帖。
4. 上报内容（每条新发现）：标题、来源链接、给什么（配置/时长/流量/IP）、参与方式与截止规则（原文可见的才写）、与用户需求的关系（如是否满足 PlayEdu 最低线 2 核/4GB/20GB、是否常驻在线）、核验状态（读了哪几页、哪句是推断）。
5. 无新发现 → 不发消息，只更新已见清单，并在 ~/workspace/deal-watch/run.log 追加一行（时间+查了哪几个来源+0 新发现）。

前车之鉴（必须遵守）：RackNerd × AdminBolt 赠送帖（lowendtalk.com/discussion/221872）已于 2026-10-26 结束、150 台全送完，但帖子至今仍有人刷关键词——“帖子有新回复”不等于“活动还开放”。判断活动状态只认主办方（发帖人 dustinc 之类）的最新公告原文，不认跟帖热度。该帖已记入已见清单，永不上报；除非主办方在该帖或新帖里明确宣布新一轮。

运行日志只写 ~/workspace/deal-watch/ 下的文件，不动 MEMORY.md。
