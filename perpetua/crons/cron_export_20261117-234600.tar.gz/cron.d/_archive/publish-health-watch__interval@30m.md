---
id: publish-health-watch
title: 发布健康常量巡检（每30分钟）
enabled: true
owner: goal:karenvsai
mode: task
schedule:
  kind: interval
  timezone: Asia/Shanghai
  at: 2026-10-11T16:31:42
  every: 30m
delivery:
  - chat_id: bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46
metadata:
  tags: [cron:automatic-interval-anchor]
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","event_kind":"message","require_mention":false,"device_id":"540d94c12687e47c"}'
  presentation_locale: en-US
---
发布健康常量巡检（D20261011-005，每30分钟）：
运行 `python3 /home/hatch/data/perpetua/publish_health.py`，检查三项管线健康常量：
1. 距上次发布 ≤18h（空转线）
2. 过去24h 发布数 ≥2
3. 排期 vs 实际发布偏差 ≤15min

脚本 exit=0 且无 alerts → 本轮静默，只在 run log 记 metrics。
有 CRITICAL/WARNING → 把 alerts 全文带回 handoff（metrics 一起），需要用户知晓。
API 熔断时脚本会自行跳过，不要误报为健康。
