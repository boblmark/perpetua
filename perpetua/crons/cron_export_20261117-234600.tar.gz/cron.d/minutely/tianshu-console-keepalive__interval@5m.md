---
id: tianshu-console-keepalive
title: 天枢控制台保活（18901，每5分钟）
enabled: true
mode: task
schedule:
  kind: interval
  timezone: Asia/Shanghai
  at: 2026-10-14T20:43:04
  every: 5m
delivery:
  - chat_id: bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46
metadata:
  tags: [cron:automatic-interval-anchor]
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","event_kind":"message","require_mention":false,"device_id":"7dfdded3-def2-43da-8e2e-257146640fc9"}'
  presentation_locale: en-US
---
天枢控制台保活（每5分钟）：检查 http://127.0.0.1:18901 是否可达。

执行：
```
code=$(curl -s -o /dev/null -w "%{http_code}" --max-time 10 http://127.0.0.1:18901/)
if [ "$code" != "200" ]; then
  cd /home/hatch/platform && setsid nohup python3 console/server.py 18901 >> /home/hatch/data/tianshu_console.log 2>&1 &
  sleep 5
  code2=$(curl -s -o /dev/null -w "%{http_code}" --max-time 10 http://127.0.0.1:18901/)
  echo "restarted console, health=$code2" >> ~/memory/$(date +%Y-%m-%d).md
fi
```

启动必须用 setsid（2026-11-06 实测根因：裸 nohup 拉起的进程随 worker 会话结束被连带杀掉，约 2 分钟即死；setsid 脱离会话后才站住）。

健康时静默，只在重启后记一笔到当日 memory 日志。不打扰用户。
