---
id: swap-detector
title: 沙箱换机检测与自动恢复（boot_id）
enabled: true
mode: task
schedule:
  kind: interval
  timezone: Asia/Shanghai
  at: 2026-11-17T08:19:45
  every: 5m
timeout_secs: 900
delivery:
  - chat_id: bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46
metadata:
  tags: [cron:automatic-interval-anchor]
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","event_kind":"message","require_mention":false,"device_id":"540d94c12687e47c"}'
  presentation_locale: en-US
---
沙箱换机检测与自动恢复：每轮执行 `bash /home/hatch/data/perpetua/swap_detector.sh`。脚本自行比对当前 boot_id 与持久状态文件（/home/hatch/data/perpetua/swap_detector_state），变化时自动运行 fleet_recovery.sh 按 Rule 11 恢复清单拉起（hostname、known_hosts、10 个 systemd unit、三合一验真、mux master 重建、外围探活），幂等且自带 flock 单飞。

- 输出 NO_CHANGE：无事，静默，不打扰用户。
- 输出 SWAP_DETECTED：如实汇报 old/new boot_id 与 recovery 结果（ok/degraded/failed），附 fleet_recovery.log 最后 30 行。
- recovery=failed 或脚本报错（exit 3/4）：汇报失败细节并附日志尾部；不要自行重试恢复、不要手改状态文件、不要 kill 任何进程、不要用 pkill。
- 绝不打印 credential-proxy drop-in 内容；绝不杀 mux master。
- 状态文件与历史文件（swap_history.log）由脚本维护，不要手改。Marvis 重建不在本任务范围，换机后仍等用户一句话才重建。
