---
id: marvis-keepalive
title: Marvis 保活与换机自动恢复
enabled: true
mode: task
schedule:
  kind: interval
  timezone: Asia/Shanghai
  at: 2026-11-17T09:40:19
  every: 5m
timeout_secs: 900
delivery:
  - chat_id: bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46
metadata:
  tags: [cron:automatic-interval-anchor]
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","event_kind":"message","require_mention":false,"device_id":"540d94c12687e47c"}'
  presentation_locale: en-US
---
Marvis 保活与换机自动恢复：每轮执行 `bash /home/hatch/workspace/marvis-native/marvis_restore.sh`（ensure 模式）。脚本自带 mkdir 单飞锁，健康时只做状态同步（静默）；Marvis 倒下或换机后自动按序恢复（用户、machine-id 钉、dpkg 安装、状态还原、Xvfb/VNC/隧道拉起）。

- 输出 DONE healthy 且无 STATE_RESTORED/FAIL：无事，静默，不打扰用户。
- 出现 STATE_RESTORED、重装或拉起动作：如实汇报恢复了什么（附日志关键行）。
- 出现 FATAL/FAIL 或 restore failsafe：汇报失败细节并附日志尾部；不要自行重试恢复、不要手改状态备份、不要 kill 进程、不要用 pkill。
- 绝不跑 apt -f install（会卸 Marvis）；绝不替用户登录（登录只能用户在 VNC 里亲自做）。
- 状态备份 /home/hatch/data/marvis-state 由脚本维护，不要手改。
