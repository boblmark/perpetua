---
id: sleep-night-patrol
title: 睡眠夜间巡检（每10分钟，含 Webhook 实时事件流）
enabled: true
mode: task
schedule:
  kind: interval
  timezone: Asia/Shanghai
  at: 2026-10-22T02:01:31
  every: 10m
timeout_secs: 1200
delivery:
  - chat_id: bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46
metadata:
  tags: [cron:automatic-interval-anchor]
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","event_kind":"message","require_mention":false,"device_id":"540d94c12687e47c"}'
  presentation_locale: en-US
---
睡眠夜间巡检（用户 cgb2026 的睡眠监测）。数据源三条：① Webhook 实时事件流（主通道，2026-10-22 上线：Sleep as Android 检测到事件即 POST 到 kb.viralloopapp.com/sleep-hook，落盘 VPS 后每 5 分钟镜像回本机）；② SleepCloud 整段记录（段结束才有）；③ health-cli 仅作参考（Health Connect 平台同步 bug 已报备，暂不可靠）。

执行步骤：
1. 时间窗检查：取当前 Asia/Shanghai 时间。不在 00:00–08:30 之间 → 只在 ~/memory 当日日志记一行「窗口外跳过」，静默结束。
2. 读状态文件 /home/hatch/data/sleep_monitor/state.json（不存在则按首次处理：{"processed": []}）。processed 记录已处理过的 SleepCloud 记录标识；event_watermark 记录已处理到的最后一个 Webhook 事件 received_at；live_proof 记录实时通道是否已收到过首个真实事件。
3. 【实时事件流】读 /home/hatch/data/sleep_monitor/events_remote.jsonl（可能不存在则跳过本节）和 /home/hatch/data/sleep_monitor/events.jsonl（本机自测事件，通常可忽略）。过滤：value1/value2/value3 任一含 "selftest" 的事件一律忽略。只处理 received_at 晚于 state.json 里 event_watermark 的新事件；处理完把 event_watermark 更新为最新一条的 received_at 并写回 state.json。
   事件含义：sleep_tracking_started/stopped/paused/resumed=追踪开始/停止/暂停/恢复；sound_event_snore=检测到打鼾；antisnoring=App 止鼾功能触发（说明鼾声达到 App 判定强度）；sound_event_talk/cough/baby/laugh=梦话/咳嗽/婴儿哭/笑声；awake/not_awake=醒来/入睡；rem=REM 期估计开始；apnea_alarm=疑似呼吸暂停告警。
   实时异常（命中任一 → 本轮报告第一行写明异常要点、事件名与时间）：
   - 出现 apnea_alarm 事件；
   - 任意连续 30 分钟窗口内 antisnoring ≥5 次；
   - 任意连续 30 分钟窗口内 sound_event_snore ≥20 次（打鼾密集）；
   - sleep_tracking_stopped 且距同段 started 不足 3 小时、且停止时刻早于 05:00（整夜过早中断）。
   首次真实事件：若新事件里有第一条非自测真实事件、且 state.json 无 live_proof → 报告里注明「实时通道已收到首个真实事件：<事件名 时间>」，并置 live_proof=true 写回（只报这一次）。
   其余新事件只在 ~/memory 当日日志记一行汇总（本轮新增 N 条、其中打鼾 x 次、止鼾 y 次），不单独报告。
4. 查 Health Connect 同步状态：运行 health-cli status --provider healthconnect（命令不存在或报错则记录原样，不重试刷屏），记下 sleep 的 record_count。
5. 查 SleepCloud：用浏览器打开 https://sleepcloud.urbandroid.org（该浏览器已登录 cgb479023@gmail.com，服务条款已同意），进 GRAPHS 页看是否有睡眠记录。有记录时，读取最新 3 条的日期、开始/结束时间、时长、评分（页面可见原文），以及页面可见的打鼾/噪声信息。
6. 对比 state.json：出现未处理过的新记录 → 逐条分析并把标识追加进 state.json 的 processed（写回文件），分析结果记入 ~/memory 当日日志。分析口径：时长（≥7h 良好，5–7h 一般，<5h 差）、评分（≥80 好，60–79 一般，<60 差）、打鼾占比（<10% 正常，10–30% 偏高，>30% 异常）。
7. 报告规则（写进本轮报告，主 agent 会转达）：
   - 实时事件异常或整段记录异常（整段已结束但时长<3h 且结束早于 05:00；或评分<60；或打鼾占比>30%）→ 报告第一行写明异常要点和数据。
   - 发现整段新记录但无异常 → 报告里简述这条记录的关键数据（日期/时长/评分/打鼾）。
   - 只有实时事件无异常 → 只写日志，不单独报告（报告写「本轮无新数据」即可，事件汇总在日志里）。
   - 什么都没有 → 报告只写「本轮无新数据」，保持简短。
8. 禁止事项：不要调用 device.invoke health.backfill（平台 bug 已知，6 次复现，避免无意义重试）；不要给用户提任何操作要求；不要改 SleepCloud/Sleep 的任何设置；浏览器只读。
