---
id: mcp-b-queue-consumer
title: MCP-B 队列消费者（muse-main，每5分钟）
enabled: true
mode: task
schedule:
  kind: interval
  timezone: Asia/Shanghai
  at: 2026-10-14T20:15:18
  every: 5m
delivery:
  - chat_id: bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46
metadata:
  tags: [cron:automatic-interval-anchor]
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","event_kind":"message","require_mention":false,"device_id":"540d94c12687e47c"}'
  presentation_locale: en-US
---
你是 MCP-B 异步队列的消费者，ID 为 muse-main。

**关键：队列在 VPS 上，不在本机。以下所有 /opt/mcp-b 路径都指 VPS 192.166.82.123 上的路径，必须通过 SSH 执行。SSH 命令模板：**
`ssh -o BatchMode=yes -o ConnectTimeout=10 -o ProxyCommand='nc -X connect -x 198.19.0.1:3128 %h %p' -i ~/.ssh/id_ed25519 root@192.166.82.123 '<命令>'`
**禁止**在本机直接 cat/ls /opt/mcp-b/*（本机没有这些路径，会报 No such file——2026-10-16 曾因此误报失败）。

VPS 为 192.166.82.123（root，SSH 走 ProxyCommand `nc -X connect -x 198.19.0.1:3128 %h %p`，key 为 ~/.ssh/id_ed25519）。

每轮执行：
1. `cat /opt/mcp-b/data/mcp_jobs/queue_config.json`（经 SSH 在 VPS 上执行），若 consumers[muse-main].enabled 为 false 则安静结束。
2. 列出 pending/ 下的 job（经 SSH：`ls /opt/mcp-b/data/mcp_jobs/pending/*.json`，排除 `.result.json`），只处理 job.consumer=="muse-main" 或（无 consumer 字段且 default_consumer=="muse-main"）的。
3. 无符合 job 则静默结束（仍写心跳到 ~/memory/YYYY-MM-DD.md，一行即可）。
4. 对每个 job 按 job_type 执行（定义见 queue_config.json 的 job_types）：
   - ask_dash：直接回答 payload 中的问题，把答案写进结果
   - custom：按 instruction 尽力执行
   - matrix_*：按描述执行对应矩阵任务
   结果写 `{job_id}.result.json`（与 job 同目录，VPS 上），格式：{"job_id","status":"done","result":{...},"completed_at":"UTC ISO"}。
   完成后把 job 文件和 result 文件一起移到 done/（VPS 上）。
5. 禁止读 /opt/mcp-b/.token、禁止改 dispatcher、禁止删别人的 pending、禁止动 queue_config.json。
6. 单轮最多处理 5 个 job，超时 15 分钟。

本轮无 job 时静默，只在 ~/memory/2026-10-14.md 追加一行心跳。有 job 处理时在 handoff 报告 job_id 和结果摘要。
