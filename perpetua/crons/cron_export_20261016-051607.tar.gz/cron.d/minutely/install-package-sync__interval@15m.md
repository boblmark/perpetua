---
id: install-package-sync
title: 安装包同步检查
enabled: true
mode: task
schedule:
  kind: interval
  timezone: Asia/Shanghai
  at: 2026-10-14T11:00:37
  every: 15m
delivery:
  - chat_id: bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46
metadata:
  tags: [cron:automatic-interval-anchor]
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","event_kind":"message","require_mention":false,"device_id":"18a85f72-3b82-4216-978c-008c08fe5597"}'
  presentation_locale: en-US
---
安装包同步检查（每 15 分钟）：

0. 先看是否有上次推送失败的标记（/home/hatch/data/perpetua/.github_push_pending）：
   有 → 直接跑 `bash /home/hatch/data/perpetua/github_sync.sh` 重试推送（不重建安装包），
   handoff 里报告推送结果。成功后脚本会自动清除标记。

1. 计算当前源文件校验和（口径唯一真相源：/home/hatch/data/perpetua/package_checksum.py，
   覆盖顶层 .py/.sh、vps_console、platform_scripts、平台配置）：
```bash
python3 /home/hatch/data/perpetua/package_checksum.py
```

2. 对比 `/home/hatch/workspace/your_files/.install_package_manifest.json` 中的 sha256。

3. 如果不一致（有增删改）→ 运行 `bash /home/hatch/data/perpetua/build_install_package.sh` 重建安装包。
   构建脚本末尾会自动：生成新鲜 cron 导出（替代旧快照）→ 调用 github_sync.sh 推送 GitHub。

4. 如果一致且无推送标记 → 静默，不打扰用户。

5. 重建后在 handoff 中记录：重建了哪两个包、新的校验和前 16 位、GitHub 是否同步成功。

注意：只检测源码扩展名（.py/.html/.js/.css/.sh/.md/.txt/.yaml/.yml/.service/.json），排除 .log/.bak/__pycache__/img_cache 等非源码——2026-10-14 修复：原 `vps_console/*` 通配把 keepalive 日志（perception_keepalive.log 等）也纳入校验，导致每 15 分钟误报漂移、空转重建。校验口径须与 build_install_package.sh 的 manifest 计算保持一致（都调 package_checksum.py）。
