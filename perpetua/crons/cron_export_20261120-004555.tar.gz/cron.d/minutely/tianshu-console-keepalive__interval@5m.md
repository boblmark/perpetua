---
id: tianshu-console-keepalive
title: 天枢控制台保活（18901，每5分钟）
enabled: true
mode: task
schedule:
  kind: interval
  timezone: Asia/Shanghai
  at: 2026-10-14T20:43:04
  every: 5m
delivery:
  - chat_id: bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46
metadata:
  tags: [cron:automatic-interval-anchor]
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","event_kind":"message","require_mention":false,"device_id":"540d94c12687e47c"}'
  presentation_locale: en-US
---
天枢控制台保活（每5分钟）：检查 http://127.0.0.1:18901 是否可达。

执行：
```
code=$(curl -s -o /dev/null -w "%{http_code}" --max-time 10 http://127.0.0.1:18901/)
if [ "$code" != "200" ]; then
  if [ -f /etc/systemd/system/tianshu-console-18901.service ]; then
    systemctl restart tianshu-console-18901.service 2>/dev/null
    via="systemctl"
  else
    cd /home/hatch/platform && setsid nohup python3 console/server.py 18901 >> /home/hatch/data/tianshu_console.log 2>&1 &
    via="bare-fallback"
  fi
  sleep 5
  code2=$(curl -s -o /dev/null -w "%{http_code}" --max-time 10 http://127.0.0.1:18901/)
  echo "restarted console via $via, health=$code2" >> ~/memory/$(date +%Y-%m-%d).md
fi
```

P0-3（2026-11-18）：systemd 拥有该服务，unit 文件存在时走 systemctl restart；仅 unit 文件缺失（换机后 fleet_recovery 尚未重装 unit 的窗口）时才裸拉。绝不 pkill unit 的 MainPID。

启动必须用 setsid（裸拉回退时；2026-11-06 实测根因：裸 nohup 拉起的进程随 worker 会话结束被连带杀掉，约 2 分钟即死；setsid 脱离会话后才站住）。

健康时静默，只在重启后记一笔到当日 memory 日志。不打扰用户。
