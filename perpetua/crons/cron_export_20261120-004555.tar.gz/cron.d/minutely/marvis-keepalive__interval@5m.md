---
id: marvis-keepalive
title: Marvis 保活与换机自动恢复
enabled: true
mode: task
schedule:
  kind: interval
  timezone: Asia/Shanghai
  at: 2026-11-17T09:40:19
  every: 5m
timeout_secs: 900
delivery:
  - chat_id: bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46
metadata:
  tags: [cron:automatic-interval-anchor]
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","event_kind":"message","require_mention":false,"device_id":"540d94c12687e47c"}'
  presentation_locale: en-US
---
Marvis 保活与换机自动恢复：每轮执行 marvis_restore.sh（ensure 模式）。脚本自带 mkdir 单飞锁，健康时只做状态同步（静默）；Marvis 倒下或换机后自动按序恢复（用户、machine-id 钉、dpkg 安装、状态还原、Xvfb/VNC/隧道拉起）。

【后台运行铁律（Rule 34，2026-11-18 #102 教训：前台跑恢复被 180 秒 exec 超时中途杀死，dpkg 半安装）】
- 绝不前台直接跑 `bash marvis_restore.sh`：完整恢复（dpkg 安装 + 状态还原 + 拉起）可能超过 180 秒，前台跑会被 exec 超时杀死在半路。
- 先查锁：若 /home/hatch/data/perpetua/marvis_restore.lockdir 存在且其中 pid 仍存活，说明上一轮恢复仍在跑——不要再起一个，直接进入轮询。
- 否则以后台方式拉起：`setsid nohup bash /home/hatch/workspace/marvis-native/marvis_restore.sh > /dev/null 2>&1 < /dev/null &`（setsid 脱离，exec 超时杀不死它；脚本自己的 log() 仍写 /home/hatch/data/perpetua/marvis_restore.log）。
- 轮询等 DONE：每 30 秒看一次日志尾部找 `=== marvis_restore DONE` 行，最多等约 10 分钟；单次 exec 轮询不超过 150 秒，分多次 exec 完成。DONE 出现即按下面口径汇报。
- 若 10 分钟仍未 DONE：不要杀、不要重跑，汇报“恢复仍在跑（附日志尾部）”，下一轮继续轮询。
- 若本轮执行被中断（超时/换机）后重进：先查 lockdir（pid 是否存活）+ 日志尾部 + `dpkg-query -W -f='${Status}' com.tencent.marvis`，确认上一轮恢复是仍在跑、已 DONE 还是死在半路；死在半路且锁已释放才可重跑（仍以后台方式），并在汇报里说明中断续跑。

- 输出 DONE healthy 且无 STATE_RESTORED/FAIL：无事，静默，不打扰用户。
- 出现 STATE_RESTORED、重装或拉起动作：如实汇报恢复了什么（附日志关键行）。
- 出现 FATAL/FAIL 或 restore failsafe：汇报失败细节并附日志尾部；不要自行重试恢复、不要手改状态备份、不要 kill 进程、不要用 pkill。
- 绝不跑 apt -f install（会卸 Marvis）；绝不替用户登录（登录只能用户在 VNC 里亲自做）。
- 状态备份 /home/hatch/data/marvis-state 由脚本维护，不要手改。
