---
id: layerone-nano-mini-flash-buy
title: LayerOne $7 gc.nano-mini 13:00 抢购
enabled: true
mode: task
schedule:
  kind: runonce
  timezone: Asia/Shanghai
  at: 2026-11-20T13:00:00
delivery:
  - chat_id: bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46
metadata:
  tags: [cron:exact-time]
  originating_chat_context_json: '{"chat_id":"bac23fc4-bf5b-4b2b-b3f5-b4c98f41ba46","origin_provider":"main","chat_kind":"direct","event_kind":"message","require_mention":false,"device_id":"540d94c12687e47c"}'
  presentation_locale: en-US
---
# LayerOne gc.nano-mini $7 闪购 — 设置未完成，禁止购买

状态：SETUP INCOMPLETE。付款授权与钱包尚未就绪，**本轮不得购买、不得下单、不得结账**。本任务只是占位，等授权完成后再由主代理把执行指令写进来。

已定条款（待授权后执行）：
- 商品：LayerOne gc.nano-mini — 1 vCPU / 1 GB 内存 / 15 GB NVMe / 3 TB 流量 @ 500 Mbps，Tampa 数据中心，年付 $7.00，终身锁定价
- 购买条件：仅在 2026-11-20 13:00 CST（美东午夜重置）补货上架、且仍有库存时购买 1 台；售罄即停止，不买替代款
- 上限：总价不超过 $10.00 USD（含税费）
- 来源：https://layeronecloud.com/early-black-friday#deals ；LET 帖 https://lowendtalk.com/discussion/223566
- 下单窗口：2026-11-20 13:00–13:30 CST

待办（主代理在授权通过后完成）：
1. 确认钱包已连接（Stripe Link 或 Shop Pay）且有可用付款方式
2. 走 permissions.preapprove 拿到该任务的付款授权
3. 把本任务体替换为执行指令（浏览器结账流程）
4. 13:00 到点自动执行，完成后向主聊天汇报结果（成功含订单号/失败含原因）
